from flask import Flask, render_template, request, jsonify, send_file, session, redirect, url_for, flash, send_from_directory
import os
import google.generativeai as genai
import re
from dotenv import load_dotenv
import time
from google.api_core import retry, exceptions
import speech_recognition as sr
from gtts import gTTS
import tempfile
import uuid
from werkzeug.security import generate_password_hash, check_password_hash
from pymongo import MongoClient

app = Flask(__name__)
app.secret_key = os.urandom(24)  # for session management

# MongoDB setup
MONGO_URI = "mongodb+srv://akila_12345:<db_password>@cluster0.icdphl8.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(MONGO_URI)
db = client['fitbot_db']
users_collection = db['users']

def validate_password(password):
    """
    Validate that the password meets the requirements:
    - At least 8 characters long
    - Contains at least one letter
    - Contains at least one digit
    """
    if len(password) < 8:
        return False
    if not re.search(r'[A-Za-z]', password):
        return False
    if not re.search(r'\d', password):
        return False
    return True

# Load environment variables
load_dotenv()

# Configure the API key
api_key = os.getenv('GOOGLE_API_KEY')
if not api_key:
    raise ValueError("No API key found. Please set the GOOGLE_API_KEY environment variable.")

genai.configure(api_key=api_key)

# Initialize speech recognition
recognizer = sr.Recognizer()

# Create temp directory for audio files if it doesn't exist
TEMP_DIR = "temp_audio"
if not os.path.exists(TEMP_DIR):
    os.makedirs(TEMP_DIR)

def clean_old_audio_files():
    """Clean up old audio files from temp directory"""
    for file in os.listdir(TEMP_DIR):
        file_path = os.path.join(TEMP_DIR, file)
        try:
            if os.path.isfile(file_path) and time.time() - os.path.getmtime(file_path) > 300:  # 5 minutes
                os.remove(file_path)
        except Exception as e:
            print(f"Error cleaning up file {file_path}: {e}")

def text_to_speech(text):
    """Convert text to speech and return the path to the audio file"""
    clean_old_audio_files()
    
    # Create a unique filename
    filename = f"speech_{uuid.uuid4()}.mp3"
    filepath = os.path.join(TEMP_DIR, filename)
    
    # Generate speech
    tts = gTTS(text=text, lang='en', slow=False)
    tts.save(filepath)
    
    return filepath

def speech_to_text(audio_file):
    """Convert speech to text"""
    try:
        with sr.AudioFile(audio_file) as source:
            audio = recognizer.record(source)
            text = recognizer.recognize_google(audio)
            return text
    except Exception as e:
        print(f"Error in speech recognition: {e}")
        return None

# Define generation configuration
generation_config = {
    "temperature": 0.7,
    "top_p": 0.95,
    "top_k": 64,
    "max_output_tokens": 2048,
}

# Create the model
model = genai.GenerativeModel(
    model_name="gemini-1.5-flash-latest",
    generation_config=generation_config
)

system_prompt = """You are a helpful healthcare chatbot designed to provide general medical information and guidance. 
Important disclaimers:
1. You are not a replacement for professional medical care
2. In emergencies, always advise users to call emergency services or visit the nearest hospital
3. Your advice is for informational purposes only

Please collect the following information from users in this format:
Gender: user's gender
Age: user's age
Main Symptoms: user's current symptoms or health concerns

After collecting this information, you should:
1. Ask clarifying questions about symptoms if needed
2. Provide general information about possible causes
3. Suggest when to seek professional medical care
4. Offer general lifestyle and preventive advice
5. Recommend relevant health screenings based on age and gender

If users ask about:
- Emergencies: Direct them to emergency services
- Specific diagnoses: Remind them to consult a healthcare provider
- Medication advice: Refer them to their doctor or pharmacist
- Mental health crises: Provide suicide prevention hotline and emergency resources

Respond with 'Please provide your gender and age first, followed by your main health concern' 
if users haven't provided their information."""

# Custom retry strategy
retry_strategy = retry.Retry(
    initial=1.0,
    maximum=60.0,
    multiplier=2.0,
    predicate=retry.if_exception_type(
        exceptions.ResourceExhausted,
        exceptions.ServiceUnavailable
    )
)

def send_message_with_retry(chat, message):
    try:
        return chat.send_message(message)
    except Exception as e:
        if "429" in str(e):  # Rate limit error
            time.sleep(2)
            return chat.send_message(message)
        raise e

# Start the chat session
chat = model.start_chat(history=[])
send_message_with_retry(chat, system_prompt)
initial_message = ("Welcome to the Healthcare Assistant! To better assist you, please provide your information in this format:\n\n"
                  "Gender: your gender\n"
                  "Age: your age\n"
                  "Main Symptoms: briefly describe your health concern\n\n"
                  "Remember: This is for informational purposes only and not a replacement for professional medical care.")
send_message_with_retry(chat, initial_message)

def format_response(text):
    # Replace markdown-style bold text with HTML bold tags
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', text)
    
    # Replace markdown-style list items with HTML list items
    text = re.sub(r'\* (.*?)\n', r'<li>\1</li>', text)
    
    # Wrap list items with <ul> tags
    text = re.sub(r'(<li>.*?</li>)', r'<ul>\1</ul>', text, flags=re.DOTALL)
    
    # Convert newlines to <br> for single line breaks
    text = text.replace('\n', '<br>')
    
    # Add warning style for emergency messages
    text = re.sub(
        r'(EMERGENCY|URGENT|Call emergency services|dial 911|seek immediate medical attention)',
        r'<span style="color: red; font-weight: bold;">\1</span>',
        text,
        flags=re.IGNORECASE
    )

    return text

# Authentication routes
@app.route('/login', methods=['POST'])
def login():
    data = request.json
    user = users_collection.find_one({'email': data['email']})
    if user and check_password_hash(user['password'], data['password']):
        session['user_email'] = user['email']
        return jsonify({
            'success': True,
            'gender': user['gender'],
            'age': user['age']
        })
    return jsonify({'success': False, 'message': 'Invalid email or password'})

@app.route('/signup', methods=['POST'])
def signup():
    try:
        data = request.json
        # Validate required fields
        if not all(key in data for key in ['email', 'password', 'gender', 'age']):
            return jsonify({
                'success': False,
                'message': 'Missing required fields: email, password, gender, and age are required'
            }), 400

        # Validate email format
        if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', data['email']):
            return jsonify({
                'success': False,
                'message': 'Invalid email format'
            }), 400
        
        # Check if email already exists
        if users_collection.find_one({'email': data['email']}):
            return jsonify({
                'success': False,
                'message': 'Email already registered'
            }), 400
        
        # Validate password
        if not validate_password(data['password']):
            return jsonify({
                'success': False,
                'message': 'Password must be at least 8 characters long and contain at least one letter and one number'
            }), 400

        # Validate gender
        valid_genders = ['male', 'female', 'other']
        if data['gender'].lower() not in valid_genders:
            return jsonify({
                'success': False,
                'message': 'Invalid gender. Must be one of: male, female, other'
            }), 400

        # Validate age
        try:
            age = int(data['age'])
            if age < 1 or age > 120:
                return jsonify({
                    'success': False,
                    'message': 'Age must be between 1 and 120'
                }), 400
        except ValueError:
            return jsonify({
                'success': False,
                'message': 'Invalid age format'
            }), 400

        # Create new user
        try:
            hashed_password = generate_password_hash(data['password'])
            user_doc = {
                'email': data['email'],
                'password': hashed_password,
                'gender': data['gender'].lower(),
                'age': age
            }
            users_collection.insert_one(user_doc)
            session['user_email'] = data['email']
            return jsonify({
                'success': True,
                'message': 'Account created successfully'
            })
        except Exception as db_error:
            print(f"Database error during signup: {str(db_error)}")
            return jsonify({
                'success': False,
                'message': 'Database error occurred. Please try again.'
            }), 500
    except Exception as e:
        print(f"Signup error: {str(e)}")  # Log the error
        return jsonify({
            'success': False,
            'message': 'An unexpected error occurred. Please try again.'
        }), 500

@app.route('/logout')
def logout():
    session.pop('user_email', None)
    return redirect(url_for('index'))

@app.route('/check_auth')
def check_auth():
    if 'user_email' in session:
        user = users_collection.find_one({'email': session['user_email']})
        if user:
            return jsonify({
                'authenticated': True,
                'gender': user['gender'],
                'age': user['age']
            })
    return jsonify({'authenticated': False})

@app.route('/')
def index():
    return render_template('chat.html')

@app.route('/chat', methods=['POST'])
def chat_endpoint():
    try:
        user_input = request.json.get('message')
        response = send_message_with_retry(chat, user_input)
        formatted_response = format_response(response.text)
        
        # Generate audio response
        audio_path = text_to_speech(response.text)
        
        return jsonify({
            'response': formatted_response,
            'audio_url': f'/audio/{os.path.basename(audio_path)}'
        })
    except Exception as e:
        return jsonify({
            'response': 'I apologize, but I am temporarily unavailable. Please try again in a few moments. If you have a medical emergency, please call emergency services immediately.',
            'error': str(e)
        }), 429

@app.route('/audio/<filename>')
def serve_audio(filename):
    """Serve audio files"""
    return send_file(os.path.join(TEMP_DIR, filename), mimetype='audio/mp3')

@app.route('/speech-to-text', methods=['POST'])
def handle_speech():
    """Handle speech input"""
    try:
        if 'audio' not in request.files:
            return jsonify({'error': 'No audio file provided'}), 400
        
        audio_file = request.files['audio']
        text = speech_to_text(audio_file)
        
        if text:
            return jsonify({'text': text})
        else:
            return jsonify({'error': 'Could not recognize speech'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

if __name__ == '__main__':
    app.run(debug=True)
