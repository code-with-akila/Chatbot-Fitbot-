It is a Chatbot that respond the fitness related questions. The Response is provide in the form of Ditery plan, Yoga and there types, Daily Exercise. For that purpose the data is retrive from the Gemini API.
 With the help of that API chatbot respond as per your question.
