from dotenv import load_dotenv
import os
import google.generativeai as genai

# Load environment variables
load_dotenv()

# Get and print the API key (first 8 characters only for security)
api_key = os.getenv('GOOGLE_API_KEY')
if api_key:
    print(f"API key found! First 8 characters: {api_key[:8]}...")
else:
    print("No API key found in .env file")

# Try to configure genai
try:
    genai.configure(api_key=api_key)
    # Test the configuration with a simple model list
    print("\nFetching available models...")
    models = genai.list_models()
    print("\nSuccessfully connected to Google AI API!")
    print("\nAvailable models:")
    for model in models:
        print(f"\nModel: {model.name}")
        print(f"Display name: {model.display_name}")
        print(f"Description: {model.description}")
        print(f"Generation methods: {', '.join(model.supported_generation_methods)}")
        print("-" * 80)
except Exception as e:
    print(f"\nError occurred: {str(e)}") 